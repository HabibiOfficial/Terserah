import { useState, useEffect, useRef } from "react";
import { FaWhatsapp, FaTelegram, FaInstagram, FaFacebook, FaServer, FaRobot, FaCode, FaPhoneAlt, FaTiktok, FaUsers, FaShieldAlt, FaBullhorn, FaFlag, FaGlobe, FaHeadset, FaTools, FaComments, FaStar, FaCheck, FaCartPlus, FaTrash, FaShoppingCart, FaTimes, FaBars, FaChevronUp, FaChevronLeft, FaChevronRight, FaSearch, FaListAlt, FaChartLine, FaUserTie, FaCircle, FaWallet, FaUniversity, FaMobileAlt, FaBoxOpen, FaCommentDots, FaCheckCircle, FaArrowRight } from "react-icons/fa";

type CartItem = { product: string; price: number };

function formatRp(amount: number) {
  return `Rp ${amount.toLocaleString("id-ID")}`;
}

const ALL_PRODUCTS = [
  { name: "Panel RAM 1GB", price: 1000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 2GB", price: 2000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 3GB", price: 3000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 4GB", price: 4000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 5GB", price: 5000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 6GB", price: 6000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 7GB", price: 7000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 8GB", price: 8000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 9GB", price: 9000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel RAM 10GB", price: 10000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Panel Unlimited", price: 12000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Reseller Panel", price: 15000, section: "#panel", tag: "Panel WhatsApp" },
  { name: "Bot Jaga Grup 1 Hari", price: 2000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Bot Jaga Grup 1 Minggu", price: 10000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Bot Jaga Grup 1 Bulan", price: 20000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Bot Pushkontak 3 Hari", price: 5000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Bot Pushkontak 1 Bulan", price: 20000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Bot JPM 3 Hari", price: 5000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Bot JPM 1 Bulan", price: 20000, section: "#bot", tag: "Bot WhatsApp" },
  { name: "Script JPM", price: 10000, section: "#bot", tag: "Script Bot" },
  { name: "Script CPanel", price: 10000, section: "#bot", tag: "Script Bot" },
  { name: "Script Jaga Grup", price: 15000, section: "#bot", tag: "Script Bot" },
  { name: "Script Pushkontak", price: 15000, section: "#bot", tag: "Script Bot" },
  { name: "NOKOS Indonesia +62", price: 7000, section: "#bot", tag: "NOKOS WhatsApp" },
  { name: "NOKOS Venezuela +58", price: 10000, section: "#bot", tag: "NOKOS WhatsApp" },
  { name: "NOKOS USA +1", price: 25000, section: "#bot", tag: "NOKOS WhatsApp" },
  { name: "NOKOS Afrika +27", price: 10000, section: "#bot", tag: "NOKOS WhatsApp" },
  { name: "JPM Reguler 100 Member", price: 35000, section: "#jpm", tag: "Jasa Push Member" },
  { name: "JPM Reguler 200 Member", price: 65000, section: "#jpm", tag: "Jasa Push Member" },
  { name: "JPM Premium 100 Member", price: 45000, section: "#jpm", tag: "Jasa Push Member" },
  { name: "JPM Unlimited", price: 150000, section: "#jpm", tag: "Jasa Push Member" },
  { name: "TikTok 1000 Followers", price: 25000, section: "#sosmed", tag: "Jasa Sosmed" },
  { name: "TikTok 1000 Views", price: 10000, section: "#sosmed", tag: "Jasa Sosmed" },
  { name: "TikTok 1000 Likes", price: 15000, section: "#sosmed", tag: "Jasa Sosmed" },
  { name: "Instagram 1000 Followers", price: 30000, section: "#sosmed", tag: "Jasa Sosmed" },
  { name: "Instagram 1000 Like", price: 15000, section: "#sosmed", tag: "Jasa Sosmed" },
  { name: "WA Channel 500 Followers", price: 25000, section: "#sosmed", tag: "Jasa Sosmed" },
  { name: "WA Channel 1000 Followers", price: 45000, section: "#sosmed", tag: "Jasa Sosmed" },
];

function SearchModal({ onBuy, onCart, onClose }: { onBuy: (p: string, price: number) => void; onCart: (p: string, price: number) => void; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const results = query.trim().length < 1
    ? []
    : ALL_PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.tag.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 8);

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50" onClick={onClose} />
      <div className="fixed top-[80px] left-1/2 -translate-x-1/2 w-[95%] max-w-2xl z-50">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center gap-3 px-5 py-4 border-b">
            <FaSearch className="text-[#1abc9c] text-lg shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Cari produk... (Panel, Bot, TikTok, JPM...)"
              className="flex-1 text-[#1a252f] text-base outline-none placeholder:text-slate-400"
            />
            {query && (
              <button onClick={() => setQuery("")} className="text-slate-400 hover:text-slate-600">
                <FaTimes />
              </button>
            )}
          </div>

          {query.trim().length < 1 && (
            <div className="p-5">
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-3">Kategori Populer</p>
              <div className="flex flex-wrap gap-2">
                {["Panel", "Bot", "JPM", "TikTok", "Instagram", "Script", "NOKOS"].map(t => (
                  <button key={t} onClick={() => setQuery(t)} className="bg-slate-50 hover:bg-[#1abc9c] hover:text-white text-slate-600 text-sm px-4 py-1.5 rounded-full border border-slate-200 transition-all">
                    {t}
                  </button>
                ))}
              </div>
            </div>
          )}

          {results.length > 0 && (
            <ul className="max-h-80 overflow-y-auto divide-y divide-slate-50">
              {results.map((p, i) => (
                <li key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-[#1a252f] text-sm truncate">{p.name}</div>
                    <div className="text-xs text-slate-400">{p.tag}</div>
                  </div>
                  <div className="text-red-500 font-bold text-sm shrink-0">{formatRp(p.price)}</div>
                  <div className="flex gap-1.5 shrink-0">
                    <button
                      onClick={() => { onBuy(p.name, p.price); onClose(); }}
                      className="bg-[#1abc9c] hover:bg-[#16a085] text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Beli
                    </button>
                    <button
                      onClick={() => { onCart(p.name, p.price); onClose(); }}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs px-2 py-1.5 rounded-lg transition-colors"
                    >
                      <FaCartPlus />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {query.trim().length > 0 && results.length === 0 && (
            <div className="py-10 text-center text-slate-400">
              <FaSearch className="text-4xl opacity-20 mx-auto mb-3" />
              <p className="text-sm">Produk "<span className="font-semibold">{query}</span>" tidak ditemukan</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function HowToOrderSection() {
  const steps = [
    { icon: <FaSearch className="text-2xl" />, title: "Pilih Layanan", desc: "Browse dan pilih layanan yang kamu butuhkan, lalu klik tombol Beli atau tambah ke keranjang.", num: "01" },
    { icon: <FaCommentDots className="text-2xl" />, title: "Hubungi Admin", desc: "Setelah klik Beli, kamu akan diarahkan langsung ke WhatsApp admin kami dengan detail ordermu.", num: "02" },
    { icon: <FaWallet className="text-2xl" />, title: "Lakukan Pembayaran", desc: "Bayar via transfer bank, e-wallet, atau metode lain yang tersedia. Konfirmasi ke admin setelah bayar.", num: "03" },
    { icon: <FaCheckCircle className="text-2xl" />, title: "Layanan Aktif", desc: "Setelah pembayaran dikonfirmasi, layanan akan langsung diproses dan aktif dalam hitungan menit.", num: "04" },
  ];
  return (
    <section id="how-to-order" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <SectionTitle title="🛒 Cara Order" subtitle="Pesan layanan di Habibi Store cukup 4 langkah mudah, proses cepat dan aman." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          <div className="hidden lg:block absolute top-10 left-[12.5%] right-[12.5%] h-px bg-gradient-to-r from-transparent via-[#1abc9c]/30 to-transparent" />
          {steps.map((s, i) => (
            <div key={i} className="relative flex flex-col items-center text-center group">
              <div className="relative mb-5">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#1abc9c] to-[#3498db] flex items-center justify-center text-white shadow-lg group-hover:scale-105 transition-transform">
                  {s.icon}
                </div>
                <span className="absolute -top-2 -right-2 w-7 h-7 bg-[#1a252f] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {s.num}
                </span>
              </div>
              <h3 className="font-bold text-[#1a252f] text-base mb-2">{s.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 text-center">
          <a href="#categories" className="inline-flex items-center gap-2 bg-[#1abc9c] hover:bg-[#16a085] text-white font-semibold px-8 py-3 rounded-full transition-all hover:-translate-y-0.5 shadow-md">
            Mulai Pesan Sekarang <FaArrowRight className="text-sm" />
          </a>
        </div>
      </div>
    </section>
  );
}

function PaymentSection() {
  const methods = [
    { label: "DANA", color: "bg-blue-50 border-blue-100", text: "text-blue-600", icon: <FaMobileAlt /> },
    { label: "GoPay", color: "bg-sky-50 border-sky-100", text: "text-sky-600", icon: <FaMobileAlt /> },
    { label: "OVO", color: "bg-purple-50 border-purple-100", text: "text-purple-600", icon: <FaMobileAlt /> },
    { label: "ShopeePay", color: "bg-orange-50 border-orange-100", text: "text-orange-500", icon: <FaMobileAlt /> },
    { label: "BCA", color: "bg-blue-50 border-blue-100", text: "text-blue-700", icon: <FaUniversity /> },
    { label: "BRI", color: "bg-blue-50 border-blue-100", text: "text-blue-800", icon: <FaUniversity /> },
    { label: "Mandiri", color: "bg-yellow-50 border-yellow-100", text: "text-yellow-700", icon: <FaUniversity /> },
    { label: "BSI", color: "bg-emerald-50 border-emerald-100", text: "text-emerald-700", icon: <FaUniversity /> },
    { label: "QRIS", color: "bg-slate-50 border-slate-100", text: "text-slate-700", icon: <FaWallet /> },
  ];
  return (
    <section className="py-14 bg-slate-50 border-t border-slate-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row items-center gap-8">
          <div className="shrink-0 text-center sm:text-left">
            <div className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-1">Metode Pembayaran</div>
            <div className="text-[#1a252f] font-bold text-lg">Kami menerima</div>
          </div>
          <div className="w-px h-12 bg-slate-200 hidden sm:block shrink-0" />
          <div className="flex flex-wrap justify-center sm:justify-start gap-2.5">
            {methods.map((m, i) => (
              <div key={i} className={`flex items-center gap-1.5 ${m.color} ${m.text} border rounded-xl px-4 py-2 text-sm font-bold`}>
                {m.icon}
                {m.label}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function PromoBanner({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed top-0 left-0 right-0 z-[60] bg-gradient-to-r from-[#1abc9c] via-[#16a085] to-[#1abc9c] text-white text-sm font-medium flex items-center justify-center gap-3 py-2.5 px-4">
      <span className="animate-pulse text-base">🎉</span>
      <span>
        <span className="font-bold">PROMO SPESIAL!</span> Diskon 20% untuk pembelian Panel pertama — hubungi admin sekarang!
      </span>
      <a href="https://wa.me/628131919213?text=Halo%2C%20saya%20mau%20klaim%20promo%20diskon%2020%25" target="_blank" rel="noreferrer" className="hidden sm:inline-flex items-center gap-1 bg-white/25 hover:bg-white/40 text-white font-bold text-xs px-3 py-1 rounded-full transition-all shrink-0">
        Klaim <FaArrowRight className="text-[10px]" />
      </a>
      <button onClick={onClose} className="absolute right-3 text-white/80 hover:text-white transition-colors">
        <FaTimes />
      </button>
    </div>
  );
}

function NavBar({ cartCount, onCartOpen, onSalesOpen, onSearchOpen, bannerVisible }: { cartCount: number; onCartOpen: () => void; onSalesOpen: () => void; onSearchOpen: () => void; bannerVisible: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navItems = [
    { label: "Beranda", href: "#home" },
    { label: "Kategori", href: "#categories" },
    { label: "Panel", href: "#panel" },
    { label: "Bot WA", href: "#bot" },
    { label: "JPM", href: "#jpm" },
    { label: "Sosmed", href: "#sosmed" },
    { label: "Kontak", href: "#contact" },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const topPos = bannerVisible ? "top-[42px]" : "top-0";

  return (
    <header className={`fixed left-0 right-0 z-50 transition-all duration-300 ${topPos} ${scrolled ? "bg-[#1a252f]/98 backdrop-blur-md shadow-xl py-3" : "bg-[#1a252f] py-4"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <nav className="flex items-center justify-between">
          <a href="#home" className="flex items-center gap-2.5 text-white font-bold text-xl font-montserrat shrink-0">
            <FaServer className="text-[#1abc9c] text-2xl" />
            <span>HABIBI<span className="text-[#1abc9c]">STORE</span></span>
          </a>

          <ul className={`hidden lg:flex items-center gap-1`}>
            {navItems.map((item) => (
              <li key={item.label}>
                <a href={item.href} className="text-white/85 hover:text-[#1abc9c] text-sm font-medium px-3 py-2 rounded-lg transition-colors hover:bg-white/5">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <button onClick={onSearchOpen} className="text-white/80 hover:text-[#1abc9c] transition-colors p-2 hover:bg-white/10 rounded-lg" title="Cari Produk">
              <FaSearch className="text-base" />
            </button>
            <button onClick={onCartOpen} className="relative text-white hover:text-[#1abc9c] transition-colors p-2 hover:bg-white/10 rounded-lg">
              <FaShoppingCart className="text-base" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>
            <button onClick={onSalesOpen} className="hidden sm:flex items-center gap-1.5 text-white text-sm font-medium px-3 py-2 bg-white/10 rounded-full hover:bg-[#1abc9c] transition-all">
              <FaListAlt className="text-xs" />
              <span className="hidden md:inline">Penjualan</span>
            </button>
            <button className="lg:hidden text-white p-1" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <FaTimes className="text-xl" /> : <FaBars className="text-xl" />}
            </button>
          </div>
        </nav>

        {mobileOpen && (
          <div className="lg:hidden mt-3 pb-3 border-t border-white/10">
            <ul className="flex flex-col gap-1 mt-3">
              {navItems.map((item) => (
                <li key={item.label}>
                  <a href={item.href} onClick={() => setMobileOpen(false)} className="block text-white/85 hover:text-[#1abc9c] text-sm font-medium px-3 py-2.5 rounded-lg transition-colors hover:bg-white/5">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </header>
  );
}

function HeroSlider() {
  const [current, setCurrent] = useState(0);
  const slides = [
    {
      gradient: "from-[#0f2027] via-[#203a43] to-[#2c5364]",
      icon: <FaServer className="text-[#1abc9c] text-8xl opacity-20 absolute right-20 top-1/2 -translate-y-1/2 hidden lg:block" />,
      title: "Panel WhatsApp Terlengkap",
      desc: "Panel hosting bot WhatsApp dengan spesifikasi RAM berbeda-beda. Server online 24 jam, anti delete, anti maling script, tidak boros kuota, dan anti DDOS.",
      href: "#panel",
      cta: "Lihat Panel",
    },
    {
      gradient: "from-[#141e30] via-[#243b55] to-[#1a4a6b]",
      icon: <FaRobot className="text-[#3498db] text-8xl opacity-20 absolute right-20 top-1/2 -translate-y-1/2 hidden lg:block" />,
      title: "Bot WhatsApp Premium",
      desc: "Sewa bot WhatsApp untuk berbagai keperluan: jaga grup, pushkontak, JPM, dengan harga terjangkau dan fitur lengkap.",
      href: "#bot",
      cta: "Sewa Bot",
    },
    {
      gradient: "from-[#0f0c29] via-[#302b63] to-[#24243e]",
      icon: <FaTiktok className="text-[#1abc9c] text-8xl opacity-20 absolute right-20 top-1/2 -translate-y-1/2 hidden lg:block" />,
      title: "Jasa Sosial Media",
      desc: "Tingkatkan engagement akun sosial media Anda dengan layanan like, views, dan followers berkualitas untuk TikTok, Instagram, dan WhatsApp Channel.",
      href: "#sosmed",
      cta: "Lihat Layanan",
    },
  ];

  useEffect(() => {
    const t = setInterval(() => setCurrent((c) => (c + 1) % slides.length), 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <section id="home" className="relative h-[500px] sm:h-[580px] overflow-hidden">
      {slides.map((s, i) => (
        <div key={i} className={`absolute inset-0 transition-opacity duration-1000 ${i === current ? "opacity-100" : "opacity-0"}`}>
          <div className={`absolute inset-0 bg-gradient-to-br ${s.gradient}`} />
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 20% 80%, rgba(26,188,156,0.4) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(52,152,219,0.3) 0%, transparent 50%)" }} />
          {s.icon}
        </div>
      ))}
      <div className="relative z-10 h-full flex items-center justify-center">
        <div className="text-center text-white px-4 max-w-3xl mx-auto">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 leading-tight drop-shadow-lg">
            {slides[current].title}
          </h1>
          <p className="text-base sm:text-lg opacity-90 mb-8 max-w-2xl mx-auto leading-relaxed">
            {slides[current].desc}
          </p>
          <a href={slides[current].href} className="inline-block bg-[#1abc9c] hover:bg-[#16a085] text-white font-semibold px-8 py-3 rounded-full transition-all hover:-translate-y-0.5 shadow-lg">
            {slides[current].cta}
          </a>
        </div>
      </div>
      <button onClick={() => setCurrent((c) => (c - 1 + slides.length) % slides.length)} className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/15 hover:bg-white/25 text-white w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-sm transition-all">
        <FaChevronLeft />
      </button>
      <button onClick={() => setCurrent((c) => (c + 1) % slides.length)} className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/15 hover:bg-white/25 text-white w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-sm transition-all">
        <FaChevronRight />
      </button>
      <div className="absolute bottom-5 left-0 right-0 flex justify-center gap-2 z-20">
        {slides.map((_, i) => (
          <button key={i} onClick={() => setCurrent(i)} className={`w-2.5 h-2.5 rounded-full transition-all ${i === current ? "bg-[#1abc9c] w-6" : "bg-white/50"}`} />
        ))}
      </div>
    </section>
  );
}

function StatsBar() {
  const stats = [
    { icon: <FaServer />, value: "500+", label: "Panel Terjual" },
    { icon: <FaRobot />, value: "1200+", label: "Bot Disewa" },
    { icon: <FaUsers />, value: "3000+", label: "Pelanggan" },
    { icon: <FaStar />, value: "99%", label: "Kepuasan" },
  ];
  return (
    <section className="bg-[#1a252f] py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center text-white">
          {stats.map((s, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <div className="text-[#1abc9c] text-3xl">{s.icon}</div>
              <div className="text-3xl font-bold">{s.value}</div>
              <div className="text-white/60 text-sm">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="text-center mb-12">
      <h2 className="text-2xl sm:text-3xl font-bold text-[#1a252f] mb-3 relative inline-block after:content-[''] after:absolute after:-bottom-2 after:left-1/2 after:-translate-x-1/2 after:w-16 after:h-1 after:bg-[#1abc9c] after:rounded-full">
        {title}
      </h2>
      {subtitle && <p className="text-slate-500 mt-4 max-w-2xl mx-auto text-sm sm:text-base">{subtitle}</p>}
    </div>
  );
}

function CategoriesSection() {
  const cats = [
    { icon: <FaServer />, name: "Panel WhatsApp", desc: "Hosting panel bot WhatsApp berbagai spesifikasi", count: "12 Layanan", href: "#panel" },
    { icon: <FaRobot />, name: "Sewa Bot", desc: "Sewa bot untuk jaga grup, pushkontak, dan JPM", count: "9 Layanan", href: "#bot" },
    { icon: <FaCode />, name: "Script Bot", desc: "Script bot WhatsApp siap pakai fitur lengkap", count: "4 Layanan", href: "#bot" },
    { icon: <FaPhoneAlt />, name: "NOKOS WhatsApp", desc: "Nomor kosong WhatsApp berbagai negara", count: "6 Layanan", href: "#bot" },
    { icon: <FaTiktok />, name: "Jasa Sosmed", desc: "Tingkatkan engagement akun sosial media Anda", count: "8 Layanan", href: "#sosmed" },
    { icon: <FaBullhorn />, name: "Jasa Push Member", desc: "Tambah member grup WhatsApp secara otomatis", count: "5 Layanan", href: "#jpm" },
  ];
  return (
    <section id="categories" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionTitle title="Kategori Layanan" subtitle="Pilih kategori layanan yang Anda butuhkan" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {cats.map((c, i) => (
            <a key={i} href={c.href} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:-translate-y-1 hover:shadow-md transition-all flex flex-col items-center text-center group">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#1abc9c] to-[#3498db] flex items-center justify-center text-white text-2xl mb-4 group-hover:scale-110 transition-transform">
                {c.icon}
              </div>
              <h3 className="font-bold text-[#1a252f] text-lg mb-1">{c.name}</h3>
              <p className="text-slate-500 text-sm mb-3 leading-relaxed">{c.desc}</p>
              <span className="bg-[#1abc9c] text-white text-xs font-semibold px-4 py-1.5 rounded-full">{c.count}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function PricingCard({ name, price, features, popular = false, onBuy, onCart }: {
  name: string; price: number; features: string[]; popular?: boolean;
  onBuy: () => void; onCart: () => void;
}) {
  return (
    <div className={`relative bg-white rounded-2xl p-6 shadow-sm border hover:-translate-y-1 hover:shadow-lg transition-all flex flex-col ${popular ? "border-[#1abc9c] border-2 scale-105" : "border-slate-100"}`}>
      {popular && (
        <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#1abc9c] text-white text-xs font-bold px-5 py-1.5 rounded-full shadow">
          POPULER
        </div>
      )}
      <div className="mb-4">
        <h3 className="text-xl font-bold text-[#1a252f] mb-1">{name}</h3>
        <div className="text-2xl font-extrabold text-red-500">{formatRp(price)}<span className="text-sm text-slate-400 font-normal">/bulan</span></div>
      </div>
      <ul className="flex-1 space-y-2 mb-6">
        {features.map((f, i) => (
          <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
            <FaCheck className="text-[#1abc9c] mt-0.5 shrink-0" />
            <span>{f}</span>
          </li>
        ))}
      </ul>
      <div className="flex gap-2">
        <button onClick={onBuy} className="flex-1 bg-[#1abc9c] hover:bg-[#16a085] text-white font-semibold py-2.5 rounded-xl transition-colors text-sm">
          Beli Sekarang
        </button>
        <button onClick={onCart} className="w-10 bg-slate-50 hover:bg-[#1abc9c] hover:text-white text-slate-600 border border-slate-200 rounded-xl flex items-center justify-center transition-all">
          <FaCartPlus />
        </button>
      </div>
    </div>
  );
}

const STANDARD_FEATURES = ["Server 24 Jam Online", "Anti Delete / Anti Rusuh", "Anti Maling Script", "Tidak Boros Kuota", "Anti DDOS Protection"];

function PanelSection({ onBuy, onCart }: { onBuy: (p: string, price: number) => void; onCart: (p: string, price: number) => void }) {
  const panels = [
    { name: "RAM 1GB", price: 1000, features: STANDARD_FEATURES },
    { name: "RAM 2GB", price: 2000, features: STANDARD_FEATURES },
    { name: "RAM 3GB", price: 3000, features: STANDARD_FEATURES },
    { name: "RAM 4GB", price: 4000, features: STANDARD_FEATURES },
    { name: "RAM 5GB", price: 5000, popular: true, features: [...STANDARD_FEATURES, "Priority Support"] },
    { name: "RAM 6GB", price: 6000, features: STANDARD_FEATURES },
    { name: "RAM 7GB", price: 7000, features: STANDARD_FEATURES },
    { name: "RAM 8GB", price: 8000, features: STANDARD_FEATURES },
    { name: "RAM 9GB", price: 9000, features: STANDARD_FEATURES },
    { name: "RAM 10GB", price: 10000, features: STANDARD_FEATURES },
    { name: "Unlimited", price: 12000, features: ["RAM Unlimited", ...STANDARD_FEATURES, "Premium Support"] },
    { name: "Reseller Panel", price: 15000, features: ["Harga Khusus Reseller", "Support Lengkap", "Dashboard Reseller", "Bisa Jual Kembali"] },
  ];
  return (
    <section id="panel" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionTitle title="🖥️ Panel WhatsApp" subtitle="Panel hosting bot WhatsApp dengan berbagai spesifikasi RAM. Server online 24 jam dengan berbagai fitur keamanan." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {panels.map((p, i) => (
            <PricingCard key={i} {...p} onBuy={() => onBuy(`Panel ${p.name}`, p.price)} onCart={() => onCart(`Panel ${p.name}`, p.price)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceCard({ icon, title, desc, priceText, features, onBuy, onCart }: {
  icon: React.ReactNode; title: string; desc: string; priceText: string; features?: string[];
  onBuy: () => void; onCart: () => void;
}) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 border-t-4 border-t-[#1abc9c] hover:-translate-y-1 hover:shadow-md transition-all flex flex-col">
      <div className="text-[#1abc9c] text-3xl mb-4">{icon}</div>
      <h3 className="text-lg font-bold text-[#1a252f] mb-2">{title}</h3>
      <p className="text-slate-500 text-sm mb-3 leading-relaxed">{desc}</p>
      {features && (
        <ul className="space-y-1.5 mb-4 flex-1">
          {features.map((f, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
              <FaCheck className="text-[#1abc9c] mt-0.5 shrink-0 text-xs" />
              <span>{f}</span>
            </li>
          ))}
        </ul>
      )}
      <div className="text-xl font-bold text-red-500 mb-4 mt-auto">{priceText}</div>
      <div className="flex gap-2">
        <button onClick={onBuy} className="flex-1 bg-[#1abc9c] hover:bg-[#16a085] text-white font-semibold py-2.5 rounded-xl transition-colors text-sm">
          Beli Sekarang
        </button>
        <button onClick={onCart} className="w-10 bg-slate-50 hover:bg-[#1abc9c] hover:text-white text-slate-600 border border-slate-200 rounded-xl flex items-center justify-center transition-all">
          <FaCartPlus />
        </button>
      </div>
    </div>
  );
}

function BotSection({ onBuy, onCart }: { onBuy: (p: string, price: number) => void; onCart: (p: string, price: number) => void }) {
  return (
    <section id="bot" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionTitle title="🤖 Bot WhatsApp" subtitle="Layanan sewa bot WhatsApp untuk berbagai keperluan dengan harga terjangkau dan fitur lengkap." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          <ServiceCard icon={<FaShieldAlt />} title="Bot Jaga Grup" desc="Bot untuk menjaga keamanan grup WhatsApp dari spammer, link berbahaya, dan anggota tidak diinginkan." priceText="Mulai Rp 2.000" features={["Sewa 1 Hari : Rp 2.000","Sewa 3 Hari : Rp 5.000","Sewa 7 Hari : Rp 10.000","Sewa 15 Hari : Rp 15.000","Sewa 1 Bulan : Rp 20.000","Sewa Permanen : Rp 30.000"]} onBuy={() => onBuy("Bot Jaga Grup 1 Hari", 2000)} onCart={() => onCart("Bot Jaga Grup 1 Hari", 2000)} />
          <ServiceCard icon={<FaUsers />} title="Bot Pushkontak" desc="Bot untuk mengirimkan kontak ke banyak pengguna secara otomatis dengan fitur target yang tepat." priceText="Mulai Rp 5.000" features={["Sewa 3 Hari : Rp 5.000","Sewa 7 Hari : Rp 10.000","Sewa 15 Hari : Rp 15.000","Sewa 1 Bulan : Rp 20.000"]} onBuy={() => onBuy("Bot Pushkontak 3 Hari", 5000)} onCart={() => onCart("Bot Pushkontak 3 Hari", 5000)} />
          <ServiceCard icon={<FaBullhorn />} title="Bot JPM (Push Member)" desc="Bot untuk menambah member grup secara otomatis dengan target yang dapat disesuaikan." priceText="Mulai Rp 5.000" features={["Sewa 3 Hari : Rp 5.000","Sewa 7 Hari : Rp 10.000","Sewa 15 Hari : Rp 15.000","Sewa 1 Bulan : Rp 20.000"]} onBuy={() => onBuy("Bot JPM 3 Hari", 5000)} onCart={() => onCart("Bot JPM 3 Hari", 5000)} />
        </div>

        <SectionTitle title="📝 Script Bot WhatsApp" subtitle="Script bot WhatsApp siap pakai dengan fitur lengkap dan mudah diinstal." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
          {[
            { icon: <FaCode />, title: "Script JPM", desc: "Script bot untuk Jasa Push Member dengan fitur lengkap.", price: 10000 },
            { icon: <FaServer />, title: "Script CPanel", desc: "Script bot dengan integrasi cPanel untuk manajemen mudah.", price: 10000 },
            { icon: <FaShieldAlt />, title: "Script Jaga Grup", desc: "Script bot untuk menjaga keamanan grup WhatsApp.", price: 15000 },
            { icon: <FaUsers />, title: "Script Pushkontak", desc: "Script bot untuk mengirim kontak ke banyak pengguna.", price: 15000 },
          ].map((s, i) => (
            <ServiceCard key={i} icon={s.icon} title={s.title} desc={s.desc} priceText={formatRp(s.price)} onBuy={() => onBuy(s.title, s.price)} onCart={() => onCart(s.title, s.price)} />
          ))}
        </div>

        <SectionTitle title="📱 NOKOS WhatsApp" subtitle="Nomor kosong (NOKOS) WhatsApp berbagai negara untuk keperluan registrasi akun." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { icon: <FaFlag />, title: "🇮🇩 Indonesia +62", desc: "Nomor kosong WhatsApp Indonesia untuk registrasi akun.", price: 7000 },
            { icon: <FaGlobe />, title: "🇻🇪 Venezuela +58", desc: "Nomor kosong WhatsApp Venezuela untuk registrasi akun.", price: 10000 },
            { icon: <FaGlobe />, title: "🇦🇫 Afganistan +93", desc: "Nomor kosong WhatsApp Afganistan untuk registrasi akun.", price: 10000 },
            { icon: <FaGlobe />, title: "🇿🇦 Afrika +27", desc: "Nomor kosong WhatsApp Afrika Selatan untuk registrasi akun.", price: 10000 },
            { icon: <FaGlobe />, title: "🇺🇸 USA +1", desc: "Nomor kosong WhatsApp USA untuk registrasi akun.", price: 25000 },
            { icon: <FaGlobe />, title: "🌍 Negara Lainnya", desc: "Nomor kosong WhatsApp berbagai negara lainnya tersedia.", price: 15000 },
          ].map((s, i) => (
            <ServiceCard key={i} icon={s.icon} title={s.title} desc={s.desc} priceText={formatRp(s.price)} onBuy={() => onBuy(s.title, s.price)} onCart={() => onCart(s.title, s.price)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function JpmSection({ onBuy, onCart }: { onBuy: (p: string, price: number) => void; onCart: (p: string, price: number) => void }) {
  const services = [
    { title: "JPM Reguler 100 Member", desc: "Push member ke grup WhatsApp sebanyak 100 orang.", price: 35000 },
    { title: "JPM Reguler 200 Member", desc: "Push member ke grup WhatsApp sebanyak 200 orang.", price: 65000 },
    { title: "JPM Premium 100 Member", desc: "Push member premium dengan kualitas terjamin.", price: 45000 },
    { title: "JPM Premium 200 Member", desc: "Push member premium 200 orang berkualitas tinggi.", price: 85000 },
    { title: "JPM Unlimited", desc: "Push member tanpa batas dengan layanan premium.", price: 150000 },
  ];
  return (
    <section id="jpm" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionTitle title="👥 Jasa Push Member (JPM)" subtitle="Layanan push member grup WhatsApp dengan berbagai paket yang bisa disesuaikan kebutuhan Anda." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <ServiceCard key={i} icon={<FaUsers />} title={s.title} desc={s.desc} priceText={formatRp(s.price)} onBuy={() => onBuy(s.title, s.price)} onCart={() => onCart(s.title, s.price)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function SosmedSection({ onBuy, onCart }: { onBuy: (p: string, price: number) => void; onCart: (p: string, price: number) => void }) {
  const services = [
    { icon: <FaTiktok />, title: "TikTok 1000 Followers", desc: "Tambah 1000 followers TikTok berkualitas.", price: 25000 },
    { icon: <FaTiktok />, title: "TikTok 1000 Views", desc: "Tambah 1000 views video TikTok.", price: 10000 },
    { icon: <FaTiktok />, title: "TikTok 1000 Likes", desc: "Tambah 1000 likes di video TikTok.", price: 15000 },
    { icon: <FaInstagram />, title: "Instagram 1000 Like", desc: "Tambah 1000 likes di postingan Instagram.", price: 15000 },
    { icon: <FaInstagram />, title: "Instagram 1000 Followers", desc: "Tambah 1000 followers Instagram berkualitas.", price: 30000 },
    { icon: <FaWhatsapp />, title: "WA Channel 500 Followers", desc: "Tambah 500 followers WhatsApp Channel.", price: 25000 },
    { icon: <FaWhatsapp />, title: "WA Channel 1000 Followers", desc: "Tambah 1000 followers WhatsApp Channel.", price: 45000 },
  ];
  return (
    <section id="sosmed" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionTitle title="📱 Jasa Sosial Media" subtitle="Tingkatkan engagement akun sosial media Anda dengan layanan berkualitas untuk TikTok, Instagram, dan WhatsApp Channel." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <ServiceCard key={i} icon={s.icon} title={s.title} desc={s.desc} priceText={formatRp(s.price)} onBuy={() => onBuy(s.title, s.price)} onCart={() => onCart(s.title, s.price)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSupportSection() {
  const channels = [
    {
      icon: <FaWhatsapp className="text-3xl" />,
      color: "from-[#25D366] to-[#1da851]",
      label: "WhatsApp Utama",
      value: "+62 813-1919-213",
      href: "https://wa.me/628131919213?text=Halo%2C%20saya%20ingin%20bertanya%20tentang%20layanan%20Habibi%20Store",
      badge: "Respon Cepat",
    },
    {
      icon: <FaTelegram className="text-3xl" />,
      color: "from-[#229ED9] to-[#1a7ab5]",
      label: "Telegram",
      value: "@habibihosting10",
      href: "https://t.me/habibihosting10",
      badge: "Technical Support",
    },
    {
      icon: <FaStar className="text-3xl" />,
      color: "from-[#f39c12] to-[#d68910]",
      label: "Testimoni",
      value: "Saluran WA Channel",
      href: "https://whatsapp.com/channel/0029Vb6SDXJDDmFXx0cHwF3f",
      badge: "Review",
    },
  ];

  return (
    <section id="contact" className="relative py-24 overflow-hidden bg-[#0f1923]">
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 10% 20%, #1abc9c 0%, transparent 40%), radial-gradient(circle at 90% 80%, #3498db 0%, transparent 40%)",
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, transparent, transparent 39px, rgba(255,255,255,0.5) 39px, rgba(255,255,255,0.5) 40px), repeating-linear-gradient(90deg, transparent, transparent 39px, rgba(255,255,255,0.5) 39px, rgba(255,255,255,0.5) 40px)",
        }}
      />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-[#1abc9c]/15 border border-[#1abc9c]/30 text-[#1abc9c] text-sm font-semibold px-5 py-2 rounded-full mb-5">
            <FaCircle className="text-[8px] animate-pulse" /> Online 24/7 — Siap Melayani
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Hubungi & Support</h2>
          <p className="text-white/50 max-w-xl mx-auto text-sm sm:text-base">
            Punya pertanyaan atau ingin pesan layanan? Hubungi kami langsung melalui saluran di bawah ini.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-12">
          {channels.map((c, i) => (
            <a
              key={i}
              href={c.href}
              target="_blank"
              rel="noreferrer"
              className="group relative bg-white/[0.05] hover:bg-white/[0.10] border border-white/10 hover:border-white/20 rounded-2xl p-5 flex flex-col items-center text-center gap-3 transition-all hover:-translate-y-1"
            >
              {c.badge && (
                <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-[10px] font-bold bg-gradient-to-r from-[#1abc9c] to-[#3498db] text-white px-3 py-0.5 rounded-full whitespace-nowrap">
                  {c.badge}
                </span>
              )}
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${c.color} flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform`}>
                {c.icon}
              </div>
              <div>
                <div className="text-white/50 text-xs mb-0.5">{c.label}</div>
                <div className="text-white font-semibold text-sm">{c.value}</div>
              </div>
            </a>
          ))}
        </div>

        <div className="bg-gradient-to-r from-[#1abc9c]/20 to-[#3498db]/20 border border-[#1abc9c]/25 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
          <div className="w-16 h-16 rounded-2xl bg-[#25D366] flex items-center justify-center text-white text-3xl shrink-0 shadow-lg">
            <FaWhatsapp />
          </div>
          <div className="flex-1">
            <h3 className="text-white font-bold text-xl mb-1">Ada yang bisa kami bantu?</h3>
            <p className="text-white/55 text-sm">
              Butuh jasa lain? VPS, install panel, unban WA, aplikasi premium, dan masih banyak lagi — tanyakan langsung!
            </p>
          </div>
          <a
            href="https://wa.me/628131919213?text=Halo%2C%20saya%20ingin%20tanya%20tentang%20layanan%20Habibi%20Store"
            target="_blank"
            rel="noreferrer"
            className="shrink-0 inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1da851] text-white font-semibold px-7 py-3 rounded-full transition-all hover:-translate-y-0.5 shadow-lg whitespace-nowrap"
          >
            <FaWhatsapp /> Chat Sekarang
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-[#1a252f] text-white pt-16 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="font-bold text-lg mb-4 pb-3 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-[#1abc9c]">
              Habibi Store
            </h3>
            <p className="text-white/60 text-sm leading-relaxed mb-5">Penyedia layanan panel WhatsApp, bot WhatsApp, script, dan jasa sosial media terlengkap dengan harga terjangkau dan kualitas terbaik.</p>
            <div className="flex gap-3">
              {[{ icon: <FaWhatsapp />, href: "https://wa.me/628131919213" }, { icon: <FaTelegram />, href: "https://t.me/habibihosting10" }, { icon: <FaInstagram />, href: "#" }, { icon: <FaFacebook />, href: "#" }].map((s, i) => (
                <a key={i} href={s.href} target="_blank" rel="noreferrer" className="w-9 h-9 bg-white/10 hover:bg-[#1abc9c] rounded-full flex items-center justify-center transition-all hover:-translate-y-0.5">
                  {s.icon}
                </a>
              ))}
            </div>
          </div>
          {[
            { title: "Layanan", links: [{ text: "Panel WhatsApp", href: "#panel" }, { text: "Bot WhatsApp", href: "#bot" }, { text: "Jasa Sosial Media", href: "#sosmed" }, { text: "Jasa Push Member", href: "#jpm" }, { text: "Script Bot", href: "#bot" }, { text: "NOKOS WhatsApp", href: "#bot" }] },
            { title: "Link Cepat", links: [{ text: "Beranda", href: "#home" }, { text: "Kategori", href: "#categories" }, { text: "Harga Panel", href: "#panel" }, { text: "Sewa Bot", href: "#bot" }, { text: "Admin", href: "#admin" }, { text: "Kontak", href: "#contact" }] },
            { title: "Informasi", links: [{ text: "Syarat & Ketentuan", href: "#" }, { text: "Kebijakan Privasi", href: "#" }, { text: "Cara Order", href: "#" }, { text: "Pembayaran", href: "#" }, { text: "Testimoni", href: "#" }, { text: "FAQ", href: "#" }] },
          ].map((col, i) => (
            <div key={i}>
              <h3 className="font-bold text-lg mb-4 pb-3 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-[#1abc9c]">{col.title}</h3>
              <ul className="space-y-2.5">
                {col.links.map((l, j) => (
                  <li key={j}><a href={l.href} className="text-white/60 hover:text-[#1abc9c] text-sm transition-colors">{l.text}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-white/10 pt-6 text-center text-white/50 text-sm">
          © {new Date().getFullYear()} HABIBI STORE MARKETPLACE. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
}

function CartDrawer({ items, onClose, onRemove, onClear }: { items: CartItem[]; onClose: () => void; onRemove: (i: number) => void; onClear: () => void }) {
  const total = items.reduce((s, i) => s + i.price, 0);

  const checkout = () => {
    if (items.length === 0) return;
    let msg = "Halo, saya ingin membeli layanan berikut:%0A%0A";
    items.forEach((item, idx) => { msg += `${idx + 1}. ${item.product} - ${formatRp(item.price)}%0A`; });
    msg += `%0ATotal: ${formatRp(total)}%0A%0ASaya sudah siap untuk membayar.`;
    window.open(`https://wa.me/628131919213?text=${msg}`, "_blank");
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-50" onClick={onClose} />
      <div className="fixed top-0 right-0 h-full w-full sm:w-[400px] bg-white z-50 flex flex-col shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b">
          <h3 className="font-bold text-[#1a252f] text-lg flex items-center gap-2"><FaShoppingCart /> Keranjang Belanja</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-red-500 transition-colors"><FaTimes className="text-xl" /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400">
              <FaShoppingCart className="text-5xl opacity-20 mb-3" />
              <h4 className="font-semibold">Keranjang belanja kosong</h4>
              <p className="text-sm">Tambahkan layanan ke keranjang untuk memulai</p>
            </div>
          ) : (
            items.map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-slate-50 rounded-xl p-3">
                <div className="flex-1">
                  <div className="font-semibold text-[#1a252f] text-sm">{item.product}</div>
                  <div className="text-red-500 font-bold text-sm">{formatRp(item.price)}</div>
                </div>
                <button onClick={() => onRemove(i)} className="text-slate-400 hover:text-red-500 transition-colors p-1.5">
                  <FaTrash />
                </button>
              </div>
            ))
          )}
        </div>
        <div className="p-5 border-t bg-white">
          <div className="flex justify-between mb-4 font-bold text-lg">
            <span>Total:</span>
            <span className="text-red-500">{formatRp(total)}</span>
          </div>
          <div className="flex gap-3">
            <button onClick={onClear} className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold py-3 rounded-xl transition-colors text-sm">Kosongkan</button>
            <button onClick={checkout} className="flex-1 bg-[#1abc9c] hover:bg-[#16a085] text-white font-semibold py-3 rounded-xl transition-colors text-sm flex items-center justify-center gap-1.5">
              <FaWhatsapp /> Checkout
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function SalesModal({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState("summary");
  const tabs = [{ id: "summary", label: "Ringkasan" }, { id: "transactions", label: "Transaksi" }, { id: "products", label: "Produk Terlaris" }, { id: "stats", label: "Statistik" }];
  return (
    <>
      <div className="fixed inset-0 bg-black/60 z-50" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95%] max-w-3xl max-h-[85vh] bg-white rounded-2xl z-50 flex flex-col shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b shrink-0">
          <h3 className="font-bold text-[#1a252f] text-lg flex items-center gap-2"><FaChartLine className="text-[#1abc9c]" /> Daftar Penjualan & Riwayat</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-red-500 transition-colors"><FaTimes className="text-xl" /></button>
        </div>
        <div className="flex border-b overflow-x-auto shrink-0">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`px-5 py-3.5 text-sm font-medium whitespace-nowrap transition-colors relative ${tab === t.id ? "text-[#1abc9c] after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-[#1abc9c]" : "text-slate-500 hover:text-slate-700"}`}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto p-5">
          {tab === "summary" && (
            <div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                {[{ label: "Total Pendapatan", value: "Rp 8.450.000", color: "text-[#1abc9c]" }, { label: "Total Transaksi", value: "1.247", color: "text-[#1a252f]" }, { label: "Produk Terjual", value: "3.892", color: "text-[#1a252f]" }, { label: "Pelanggan Aktif", value: "847", color: "text-[#1a252f]" }].map((s, i) => (
                  <div key={i} className="bg-slate-50 rounded-xl p-4 text-center">
                    <div className="text-slate-500 text-xs mb-1">{s.label}</div>
                    <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
                  </div>
                ))}
              </div>
              <h4 className="font-semibold text-[#1a252f] mb-3">Penjualan Bulan Ini</h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[{ label: "Panel WhatsApp", value: "Rp 3.250.000" }, { label: "Sewa Bot", value: "Rp 2.180.000" }, { label: "Jasa Sosmed", value: "Rp 1.870.000" }, { label: "JPM & Lainnya", value: "Rp 1.150.000" }].map((s, i) => (
                  <div key={i} className="bg-slate-50 rounded-xl p-4 text-center">
                    <div className="text-slate-500 text-xs mb-1">{s.label}</div>
                    <div className="text-lg font-bold text-[#1abc9c]">{s.value}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab === "transactions" && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-slate-50">{["ID Transaksi","Produk","Pelanggan","Tanggal","Status","Total"].map(h => <th key={h} className="text-left p-3 font-semibold text-[#1a252f] border-b-2 border-slate-100 whitespace-nowrap">{h}</th>)}</tr></thead>
                <tbody>
                  {[{ id:"TRX-001", prod:"Panel RAM 5GB", cust:"Andi Wijaya", date:"15 Mar", status:"Selesai", total:"Rp 5.000" }, { id:"TRX-002", prod:"Bot Jaga Grup 1 Bulan", cust:"Sari Dewi", date:"14 Mar", status:"Selesai", total:"Rp 20.000" }, { id:"TRX-003", prod:"TikTok 1000 Followers", cust:"Rudi Hartono", date:"13 Mar", status:"Diproses", total:"Rp 25.000" }, { id:"TRX-004", prod:"JPM Premium 100 Member", cust:"Budi Santoso", date:"12 Mar", status:"Selesai", total:"Rp 45.000" }, { id:"TRX-005", prod:"Script Jaga Grup", cust:"Lisa Anggraini", date:"11 Mar", status:"Pending", total:"Rp 15.000" }].map((r, i) => (
                    <tr key={i} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                      <td className="p-3 text-slate-500">{r.id}</td>
                      <td className="p-3 font-medium whitespace-nowrap">{r.prod}</td>
                      <td className="p-3 text-slate-600 whitespace-nowrap">{r.cust}</td>
                      <td className="p-3 text-slate-400">{r.date}</td>
                      <td className="p-3"><span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${r.status === "Selesai" ? "bg-green-100 text-green-700" : r.status === "Diproses" ? "bg-blue-100 text-blue-700" : "bg-yellow-100 text-yellow-700"}`}>{r.status}</span></td>
                      <td className="p-3 font-semibold">{r.total}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {tab === "products" && (
            <div className="overflow-x-auto">
              <h4 className="font-semibold text-[#1a252f] mb-4">10 Produk Terlaris</h4>
              <table className="w-full text-sm">
                <thead><tr className="bg-slate-50">{["#","Produk","Kategori","Terjual","Pendapatan"].map(h => <th key={h} className="text-left p-3 font-semibold text-[#1a252f] border-b-2 border-slate-100 whitespace-nowrap">{h}</th>)}</tr></thead>
                <tbody>
                  {[{ prod:"Panel RAM 5GB", cat:"Panel WhatsApp", sold:387, rev:"Rp 1.935.000" }, { prod:"Bot Jaga Grup 1 Bulan", cat:"Sewa Bot", sold:254, rev:"Rp 5.080.000" }, { prod:"TikTok 1000 Followers", cat:"Jasa Sosmed", sold:189, rev:"Rp 4.725.000" }, { prod:"JPM Reguler 100 Member", cat:"Jasa Push Member", sold:167, rev:"Rp 5.845.000" }, { prod:"Instagram 1000 Like", cat:"Jasa Sosmed", sold:145, rev:"Rp 2.175.000" }].map((r, i) => (
                    <tr key={i} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-bold text-[#1abc9c]">{i + 1}</td>
                      <td className="p-3 font-medium whitespace-nowrap">{r.prod}</td>
                      <td className="p-3 text-slate-500 whitespace-nowrap">{r.cat}</td>
                      <td className="p-3 font-semibold">{r.sold}</td>
                      <td className="p-3 text-[#1abc9c] font-semibold whitespace-nowrap">{r.rev}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {tab === "stats" && (
            <div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                {[{ label: "Rata-rata Transaksi", value: "Rp 6.775", color: "" }, { label: "Konversi Penjualan", value: "24.7%", color: "text-[#1abc9c]" }, { label: "Retensi Pelanggan", value: "68.3%", color: "text-[#1abc9c]" }, { label: "Rating Kepuasan", value: "4.8/5", color: "text-[#1abc9c]" }].map((s, i) => (
                  <div key={i} className="bg-slate-50 rounded-xl p-4 text-center">
                    <div className="text-slate-500 text-xs mb-1">{s.label}</div>
                    <div className={`text-xl font-bold ${s.color || "text-[#1a252f]"}`}>{s.value}</div>
                  </div>
                ))}
              </div>
              <h4 className="font-semibold text-[#1a252f] mb-4">Statistik Bulanan</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="bg-slate-50">{["Bulan","Transaksi","Pendapatan","Pelanggan Baru","Growth"].map(h => <th key={h} className="text-left p-3 font-semibold text-[#1a252f] border-b-2 border-slate-100 whitespace-nowrap">{h}</th>)}</tr></thead>
                  <tbody>
                    {[["Mar 2024","247","Rp 1.850.000","89","+12.4%"],["Feb 2024","220","Rp 1.645.000","76","+8.7%"],["Jan 2024","203","Rp 1.512.000","68","+15.2%"],["Des 2023","176","Rp 1.312.000","59","+5.9%"],["Nov 2023","166","Rp 1.238.000","54","+9.8%"]].map((r, i) => (
                      <tr key={i} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        {r.map((cell, j) => <td key={j} className={`p-3 ${j === 4 ? "text-[#1abc9c] font-semibold" : "text-slate-600"}`}>{cell}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function TestimoniSection() {
  const reviews = [
    { name: "Andi W.", loc: "Jakarta", rating: 5, text: "Panel RAM 5GB-nya mantap banget! Server stabil, nggak pernah down. Admin juga fast respon kalau ada masalah. Recommended!", service: "Panel RAM 5GB", avatar: "AW" },
    { name: "Sari D.", loc: "Surabaya", rating: 5, text: "Sudah 3 bulan langganan Bot Jaga Grup, grup aman dari spammer. Harga terjangkau banget dibanding manfaatnya. Puas!", service: "Bot Jaga Grup", avatar: "SD" },
    { name: "Rudi H.", loc: "Bandung", rating: 5, text: "JPM Premium 100 Member beneran masuk semua! Prosesnya cepat, kurang dari 1 jam sudah selesai. Langsung repeat order!", service: "JPM Premium", avatar: "RH" },
    { name: "Budi S.", loc: "Medan", rating: 5, text: "TikTok followers-nya nyata semua, nggak ada yang ghost. Akun makin rame, engagement naik signifikan. Top!", service: "TikTok Followers", avatar: "BS" },
    { name: "Lisa A.", loc: "Yogyakarta", rating: 5, text: "Script Jaga Grup-nya lengkap fiturnya, mudah diinstall. Admin sabar bantu step by step sampai bisa. Makasih!", service: "Script Jaga Grup", avatar: "LA" },
    { name: "Deni K.", loc: "Semarang", rating: 5, text: "NOKOS Indonesia-nya aman, nomor valid semua. Proses order cepat, tinggal transfer langsung dapat nomornya. Lanjut!", service: "NOKOS Indonesia", avatar: "DK" },
  ];

  return (
    <section id="testimoni" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionTitle title="⭐ Testimoni Pelanggan" subtitle="Apa kata mereka yang sudah menggunakan layanan Habibi Store?" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {reviews.map((r, i) => (
            <div key={i} className="bg-slate-50 border border-slate-100 rounded-2xl p-6 flex flex-col gap-4 hover:shadow-md hover:-translate-y-0.5 transition-all">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#1abc9c] to-[#3498db] text-white font-bold text-sm flex items-center justify-center shrink-0">
                    {r.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-[#1a252f] text-sm">{r.name}</div>
                    <div className="text-slate-400 text-xs">{r.loc}</div>
                  </div>
                </div>
                <span className="bg-[#1abc9c]/10 text-[#1abc9c] text-[10px] font-semibold px-2.5 py-1 rounded-full whitespace-nowrap shrink-0">{r.service}</span>
              </div>
              <div className="flex gap-0.5">
                {Array.from({ length: r.rating }).map((_, j) => (
                  <FaStar key={j} className="text-amber-400 text-sm" />
                ))}
              </div>
              <p className="text-slate-600 text-sm leading-relaxed flex-1">"{r.text}"</p>
              <div className="flex items-center gap-1.5 text-[#1abc9c] text-xs font-medium">
                <FaCheckCircle /> Pembelian Terverifikasi
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <a href="https://whatsapp.com/channel/0029Vb6SDXJDDmFXx0cHwF3f" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 border-2 border-[#1abc9c] text-[#1abc9c] hover:bg-[#1abc9c] hover:text-white font-semibold px-8 py-3 rounded-full transition-all">
            <FaWhatsapp /> Lihat Semua Testimoni
          </a>
        </div>
      </div>
    </section>
  );
}

function FaqSection() {
  const [open, setOpen] = useState<number | null>(null);
  const faqs = [
    { q: "Berapa lama proses aktivasi setelah pembayaran?", a: "Proses aktivasi sangat cepat, biasanya dalam 5–30 menit setelah pembayaran dikonfirmasi. Admin kami online 24/7 untuk memproses pesanan Anda." },
    { q: "Apakah panel dan bot aman digunakan?", a: "Ya, semua layanan kami aman. Panel dilengkapi fitur anti-DDOS, anti delete, anti maling script. Bot juga aman dan tidak menyalahi ketentuan WhatsApp selama digunakan secara wajar." },
    { q: "Metode pembayaran apa yang diterima?", a: "Kami menerima transfer bank (BCA, BRI, Mandiri, BSI), e-wallet (DANA, GoPay, OVO, ShopeePay), dan QRIS. Konfirmasi pembayaran ke admin via WhatsApp." },
    { q: "Apakah ada garansi untuk layanan yang dibeli?", a: "Ya, kami memberikan garansi layanan. Jika ada masalah teknis dalam periode aktif, kami siap membantu troubleshooting atau memberikan penggantian jika diperlukan." },
    { q: "Bisakah saya menjadi reseller Habibi Store?", a: "Tentu! Kami punya paket Reseller Panel dengan harga khusus. Hubungi admin untuk informasi lengkap tentang program reseller kami." },
    { q: "Bagaimana jika bot/panel saya bermasalah?", a: "Langsung hubungi admin via WhatsApp atau Telegram. Tim teknis kami siap membantu 24 jam. Proses perbaikan biasanya selesai dalam 1–2 jam." },
    { q: "Apakah NOKOS WhatsApp dijamin aktif?", a: "Ya, semua nomor NOKOS yang kami jual sudah diverifikasi aktif. Jika ada masalah dalam 24 jam pertama, kami siap ganti tanpa biaya tambahan." },
    { q: "Cara order untuk pemula gimana?", a: "Pilih layanan yang diinginkan → klik tombol 'Beli Sekarang' → otomatis terhubung ke WhatsApp admin → diskusikan kebutuhan dan lakukan pembayaran → layanan aktif!" },
  ];

  return (
    <section id="faq" className="py-20 bg-slate-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <SectionTitle title="❓ FAQ" subtitle="Pertanyaan yang sering ditanyakan pelanggan kami." />
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className={`bg-white border rounded-2xl overflow-hidden transition-all ${open === i ? "border-[#1abc9c] shadow-sm" : "border-slate-100"}`}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between gap-4 px-6 py-4 text-left"
              >
                <span className={`font-semibold text-sm sm:text-base transition-colors ${open === i ? "text-[#1abc9c]" : "text-[#1a252f]"}`}>{faq.q}</span>
                <span className={`shrink-0 w-6 h-6 rounded-full flex items-center justify-center transition-all ${open === i ? "bg-[#1abc9c] text-white rotate-180" : "bg-slate-100 text-slate-400"}`}>
                  <FaChevronUp className="text-xs" />
                </span>
              </button>
              {open === i && (
                <div className="px-6 pb-5 text-slate-500 text-sm leading-relaxed border-t border-slate-50">
                  <p className="pt-3">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="mt-10 bg-gradient-to-r from-[#1abc9c]/10 to-[#3498db]/10 border border-[#1abc9c]/20 rounded-2xl p-6 text-center">
          <p className="text-[#1a252f] font-semibold mb-1">Masih ada pertanyaan lain?</p>
          <p className="text-slate-500 text-sm mb-4">Tim kami siap menjawab pertanyaan Anda kapan saja.</p>
          <a href="https://wa.me/628131919213?text=Halo%2C%20saya%20punya%20pertanyaan%20tentang%20layanan%20Habibi%20Store" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-[#1abc9c] hover:bg-[#16a085] text-white font-semibold px-7 py-2.5 rounded-full transition-all">
            <FaWhatsapp /> Tanya Admin
          </a>
        </div>
      </div>
    </section>
  );
}

function BackToTop() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 300);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!visible) return null;
  return (
    <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="fixed bottom-24 right-6 w-11 h-11 bg-[#1a252f] hover:bg-[#2d3e50] text-white rounded-full flex items-center justify-center shadow-lg transition-all hover:-translate-y-0.5 z-40">
      <FaChevronUp />
    </button>
  );
}

export default function Home() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try { return JSON.parse(localStorage.getItem("habibi_cart") || "[]"); } catch { return []; }
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [salesOpen, setSalesOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(true);
  const [toast, setToast] = useState("");

  useEffect(() => { localStorage.setItem("habibi_cart", JSON.stringify(cart)); }, [cart]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") { e.preventDefault(); setSearchOpen(true); }
      if (e.key === "Escape") { setSearchOpen(false); setCartOpen(false); setSalesOpen(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(""), 2500); };

  const handleBuy = (product: string, price: number) => {
    const msg = encodeURIComponent(`Halo, saya ingin membeli layanan:\n${product} - ${formatRp(price)}\n\nMohon informasi lebih lanjut.`);
    window.open(`https://wa.me/628131919213?text=${msg}`, "_blank");
  };

  const addToCart = (product: string, price: number) => {
    setCart(c => [...c, { product, price }]);
    showToast("Produk ditambahkan ke keranjang!");
  };

  const removeFromCart = (i: number) => {
    setCart(c => c.filter((_, idx) => idx !== i));
    showToast("Produk dihapus dari keranjang!");
  };

  const headerHeight = bannerVisible ? "pt-[102px]" : "pt-[60px]";

  return (
    <div className="min-h-screen font-poppins">
      {bannerVisible && <PromoBanner onClose={() => setBannerVisible(false)} />}
      <NavBar cartCount={cart.length} onCartOpen={() => setCartOpen(true)} onSalesOpen={() => setSalesOpen(true)} onSearchOpen={() => setSearchOpen(true)} bannerVisible={bannerVisible} />
      <div className={headerHeight} />
      <HeroSlider />
      <StatsBar />
      <CategoriesSection />
      <PanelSection onBuy={handleBuy} onCart={addToCart} />
      <BotSection onBuy={handleBuy} onCart={addToCart} />
      <JpmSection onBuy={handleBuy} onCart={addToCart} />
      <SosmedSection onBuy={handleBuy} onCart={addToCart} />
      <TestimoniSection />
      <HowToOrderSection />
      <PaymentSection />
      <FaqSection />
      <ContactSupportSection />
      <Footer />

      {cartOpen && <CartDrawer items={cart} onClose={() => setCartOpen(false)} onRemove={removeFromCart} onClear={() => { setCart([]); showToast("Keranjang dikosongkan!"); }} />}
      {salesOpen && <SalesModal onClose={() => setSalesOpen(false)} />}
      {searchOpen && <SearchModal onBuy={handleBuy} onCart={addToCart} onClose={() => setSearchOpen(false)} />}

      <a href="https://wa.me/628131919213" target="_blank" rel="noreferrer" className="fixed bottom-6 right-6 w-14 h-14 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-full flex items-center justify-center text-2xl shadow-xl transition-all hover:scale-110 z-40">
        <FaWhatsapp />
      </a>
      <BackToTop />

      {toast && (
        <div className="fixed top-20 right-5 bg-[#1a252f] text-white px-4 py-3 rounded-xl shadow-xl text-sm z-[60] animate-in fade-in slide-in-from-right">
          {toast}
        </div>
      )}
    </div>
  );
}
